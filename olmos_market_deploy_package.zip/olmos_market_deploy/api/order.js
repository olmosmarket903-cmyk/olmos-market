export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) {
    return res.status(503).json({ error: "Telegram server sozlamalari hali kiritilmagan." });
  }

  const { name, phone, address = "", items } = req.body || {};
  if (typeof name !== "string" || !name.trim() ||
      typeof phone !== "string" || !phone.trim() ||
      !Array.isArray(items) || items.length < 1 || items.length > 40) {
    return res.status(400).json({ error: "Buyurtma ma'lumotlari to'liq emas." });
  }

  const safeItems = [];
  for (const item of items) {
    if (!item || typeof item.name !== "string" ||
        !Number.isInteger(item.quantity) || item.quantity < 1 ||
        !Number.isFinite(item.price) || item.price < 0) {
      return res.status(400).json({ error: "Mahsulot ma'lumotlari noto'g'ri." });
    }
    safeItems.push(item);
  }

  const total = safeItems.reduce((sum, item) => sum + item.quantity * item.price, 0);
  const lines = [
    "🛒 Yangi buyurtma — OLMOS MARKET", "",
    `👤 Ism: ${name.trim().slice(0, 100)}`,
    `📞 Telefon: ${phone.trim().slice(0, 40)}`,
    address ? `📍 Manzil: ${String(address).trim().slice(0, 200)}` : "",
    "", "Mahsulotlar:",
    ...safeItems.map(item =>
      `• ${item.name.slice(0, 100)} × ${item.quantity} — ${(item.price * item.quantity).toLocaleString("uz-UZ")} so'm`
    ),
    "", `Жами: ${total.toLocaleString("uz-UZ")} so'm`
  ].filter(Boolean);

  try {
    const tg = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: lines.join("\\n") })
    });
    const data = await tg.json();
    if (!tg.ok || !data.ok) {
      return res.status(502).json({ error: "Telegram buyurtmani qabul qilmadi. Bot sozlamalarini tekshiring." });
    }
    return res.status(200).json({ ok: true });
  } catch {
    return res.status(502).json({ error: "Telegram bilan bog'lanishda xatolik yuz berdi." });
  }
}
